# Base-wabot


# Cara Penginstalan
```
> pkg install git
> git clone https://github.com/caliph71/bot-wa
> cd bot-wa
> bash install.sh
> node index
```


Masih Gapaham/Error ?

Chat Me On 
[`WhatsApp`](https://wa.me/6281313726400)



Created By [`@REZZ19`]

