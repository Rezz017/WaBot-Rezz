global.owner = ['6281313726400']
global.autoread = false
global.selfmode = false
global.mess = {
group : {
welcome : `Hai @user\n◪ Welcome in group:\n├─ @subject\n├─ Intro dulu\n├─ ❏ Nama: \n├─ ❏ Umur: \n├─ ❏ Asal kota: \n├─ ❏ Kelas: \n├─ ❏ Jenis kelamin: \nFOLLOW AKUN OWNER\n➣https://www.instagram.com/ini_rezz19\n➣https://youtube.com/channel/UC8OREtGKNIBBku25tbX5e0A\n◪Jangan Lupa baca Deskripsi\n\n@desc`,
bye : `Good Bye @user`,
promote: '@user Sekarang admin!',
demote: '@user Sekarang bukan admin!'
},
error : 'Terjadi Kesalahan',
success: 'Sukses...'
}
global.prefix = '🐤'
global.author = '@6281313726400'
global.packname = 'WhatsApp Bot'

let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
